# scripts

Folder for scripts resources.
