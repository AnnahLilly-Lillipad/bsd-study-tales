# config

Folder for config resources.
