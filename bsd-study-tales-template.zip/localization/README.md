# localization

Folder for localization resources.
